library(testthat)
library(RMoE)

test_check("RMoE")
